package zoohandlung;

public interface Laufen {    
    public void laufe();
    public int getAnzahlBeine();
    public void setAnzahlBeine(int anzahl);
}
