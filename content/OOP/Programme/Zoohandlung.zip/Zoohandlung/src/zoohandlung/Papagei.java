package zoohandlung;

public class Papagei extends Tier {

    String lieblingswort;
    double spannweite;

    public Papagei(String name, double gewicht, String lieblingswort, double spannweite) {
        super(name,gewicht);
        this.lieblingswort=lieblingswort;
        this.spannweite=spannweite;
    }

    public void fliege() {
        System.out.println("Ich fliege");
    }

    public String sprich(String wort) {
        System.out.println(wort);
        return wort;
    }
}
