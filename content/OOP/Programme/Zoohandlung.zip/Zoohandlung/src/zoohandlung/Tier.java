package zoohandlung;

public abstract class Tier {

    protected String name;
    double gewicht;
    String futterzeit;
    int anzahlBeine;

    public Tier(){}
    
    public Tier(String name, double gewicht) {
        this.name = name;
        this.gewicht = gewicht;
    }

    public void laufe() {
        System.out.println("Ich laufe");
    }

    public void setAnzahlBeine(int anzahlBeine) {
        this.anzahlBeine = anzahlBeine;
    }

    public int getAnzahlBeine() {
        return anzahlBeine;
    }
    
    @Override
    public String toString(){
        return "Ich heiße "+name+" und wiege "+gewicht+" kg";
    }
}
