
package externesPackage;

import zoohandlung.Papagei;

public class ExterneMainKlasse {
    public static void main(String[] args) {
        Papagei p=new Papagei("Ara", 12.32,"Hallo", 40);
        p.sprich("Hallo");
        p.setAnzahlBeine(2);
        System.out.println(p);
    }
}
